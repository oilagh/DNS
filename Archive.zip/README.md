wjsdigudgriuh\
